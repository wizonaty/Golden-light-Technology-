document.addEventListener('DOMContentLoaded', function() {
    // Shared elements
    const authProgress = document.getElementById('authProgress');
    
    // Login Form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleAuthSubmit(this, 'login');
        });
    }
    
    // Registration Form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate passwords match
            const password = document.getElementById('regPassword').value;
            const confirmPassword = document.getElementById('regConfirmPassword').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            handleAuthSubmit(this, 'register');
        });
    }
    
    function handleAuthSubmit(form, action) {
        // Show loading state
        form.classList.add('form-submitting');
        authProgress.parentElement.classList.add('form-submitting');
        
        // Simulate API call
        setTimeout(() => {
            // Show success state
            form.classList.remove('form-submitting');
            form.classList.add('form-success');
            authProgress.parentElement.classList.add('form-success');
            
            // Update progress bar
            authProgress.style.width = '100%';
            
            // Redirect after delay
            setTimeout(() => {
                if (action === 'login') {
                    // Store login state
                    localStorage.setItem('glt_authenticated', 'true');
                    localStorage.setItem('glt_username', document.getElementById('loginUsername').value);
                    
                    // Redirect to dashboard
                    window.location.href = 'index.html';
                } else {
                    // Registration success - redirect to login
                    alert('Registration successful! Please login.');
                    window.location.href = 'login.html';
                }
            }, 1000);
        }, 2000);
    }
    
    // Check if already logged in
    if (localStorage.getItem('glt_authenticated') {
        if (window.location.pathname.includes('login.html') {
            window.location.href = 'index.html';
        }
    }
});
// Authentication Check
document.addEventListener('DOMContentLoaded', function() {
    // Redirect to login if not authenticated
    if (!localStorage.getItem('glt_authenticated')) {
        window.location.href = 'login.html';
    }
    
    // Show username in header
    const username = localStorage.getItem('glt_username');
    if (username) {
        document.querySelector('.user-profile span').textContent = username;
    }
    
    // Logout functionality
    document.querySelector('.logout-btn').addEventListener('click', function() {
        localStorage.removeItem('glt_authenticated');
        localStorage.removeItem('glt_username');
        window.location.href = 'login.html';
    });
    
    // Rest of your existing main.js code...
});